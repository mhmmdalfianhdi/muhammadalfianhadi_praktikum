<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Menu2 extends CI_Controller {

	
	public function index()
	{
		$this->load->view('template/menu');
	}
}
